﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
using KontrolerAplikacioneLogike;
using System.Windows.Forms;

namespace KontrolerKorisnickogInterfejsa
{
    public class KontrolerKI
    {
        public static Komunikacija komunikacija;
        public static Zaposleni zaposleni;
        public static Alat alat;
        public static Proizvod proizvod;
        public static NalogZaNabavku nalog;
        public static TehnoloskiProces proizvodniProces;
        public static bool PoveziSeNaServer()
        {
            if (komunikacija == null)
                komunikacija = new Komunikacija();
            return komunikacija.poveziNaServer();
        }

        public static bool Login(string korisnickoIme, string korisnickaSifra)
        {
            zaposleni = new Zaposleni();
            zaposleni.KorisnickoIme = korisnickoIme;
            zaposleni.Sifra = korisnickaSifra;

            zaposleni = komunikacija.Login(zaposleni) as Zaposleni;

            if (zaposleni == null)
            {
                System.Windows.Forms.MessageBox.Show("Sistem ne moze da prijavi zaposlenog!");
                return false;
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Sistem je uspesno prijavio zaposlenog!");
                return true;
            }
        }

        public static void PrikaziUlogovanogRadnika(Label ime, Label prezime, Label telefon, Label user, Label datum, Label vreme)
        {
            ime.Text = zaposleni.Ime;
            prezime.Text = zaposleni.Prezime;
            telefon.Text = zaposleni.Telefon;
            user.Text = zaposleni.KorisnickoIme;
            datum.Text = DateTime.Now.ToString("dd.MM.yyyy.");
            vreme.Text = DateTime.Now.ToString("HH:mm");
        }

        public static void Kraj()
        {
            komunikacija.Kraj();
            komunikacija = null;
        }

        public static void popuniCmbTipMasine(ComboBox cmb)
        {
            cmb.Items.Add("CNC strug");
            cmb.Items.Add("Stubna bušilica");
            cmb.Items.Add("Obradni centar");
            cmb.Items.Add("CNC glodalica");
            cmb.Items.Add("Brusilica");
        }

        public static void SacuvajAlat(TextBox txtNaziv, TextBox txtProizvodjac, TextBox txtVrstaAlata, TextBox txtCena, ComboBox comboBox1)
        {
            alat.NazivAlata = txtNaziv.Text;
            alat.Proizvodjac = txtProizvodjac.Text;
            alat.VrstaAlata = txtVrstaAlata.Text;
            alat.Cena = Convert.ToDouble(txtCena.Text);
            alat.TipMasine = comboBox1.SelectedItem.ToString();
            alat.TrenutnoSeKoristi = true;

            komunikacija.ZapamtiAlat(alat);

            MessageBox.Show("Sistem je sacuvao alat.");

        }


        public static void UnosAlata()
        {
            alat = komunikacija.UnesiAlat() as Alat;

            if (alat == null)
                MessageBox.Show("Sistem ne moze da unese alat!");
            else MessageBox.Show("Sistem je uneo alat!");
        }

        public static void PretragaAlata(TextBox txtNaziv, TextBox txtVrstaAlata, TextBox txtProizvodjac, ComboBox combo, DataGridView dataGridView1)
        {
            alat = new Alat();
            alat.uslov = " NazivAlata like '%" + txtNaziv.Text + "%' and VrstaAlata like '%" 
                            + txtVrstaAlata.Text + "%' and Proizvodjac like '%" + txtProizvodjac.Text + "%'";
            if (combo.SelectedItem != null) alat.uslov += " and TipMasine like '%" + combo.SelectedItem.ToString() + "%'";
            List<Alat> lista = (List<Alat>)komunikacija.PretraziAlat(alat);

            if (lista == null)
            {
                MessageBox.Show("Sistem ne moze da pronadje alate!");
                return;
            }

            dataGridView1.DataSource = lista;

            if (lista.Count == 0)
            {
                MessageBox.Show("Sistem ne moze da nadje alate po zadatoj vrednosti!");
                return;
            }

            MessageBox.Show("Sistem je našao alate po zadatoj vrednosti!");
        }

        public static void PretragaAlata(DataGridView dataGridView1)
        {
            List<Alat> lista = (List<Alat>)komunikacija.VratiSveAlate();

            dataGridView1.DataSource = lista;
        }

        public static bool ValidacijaAlat(TextBox txtNaziv, TextBox txtProizvodjac, TextBox txtVrstaAlata, TextBox txtCena, ComboBox comboBox1)
        {
            bool uRedu = true;
            string poruka = "";

            if (string.IsNullOrEmpty(txtNaziv.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: naziv alata";
                    uRedu = false;
                }
                else poruka += ", naziv alata";
                
            }
            if (string.IsNullOrEmpty(txtProizvodjac.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: proizvodjaca";
                    uRedu = false;
                }
                else poruka += ", proizvodjaca";
            }
            if (string.IsNullOrEmpty(txtVrstaAlata.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: vrstu alata";
                    uRedu = false;
                }
                else poruka += ", vrstu alata";
            }
            if (comboBox1.SelectedIndex == -1)
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: tip masine";
                    uRedu = false;
                }
                else poruka += ", tip masine";
            }
            try
            {
                double cena = Convert.ToDouble(txtCena.Text);
                if (cena <= 0)
                {
                    poruka += "\nCena mora biti veca od 0!";
                    if (uRedu)
                        uRedu = false;
                }
            }
            catch (Exception)
            {
                poruka += "\nNiste uneli validnu vrednost cene!";
                if (uRedu)
                    uRedu = false;
            }
            if (!uRedu)
            {
                MessageBox.Show("Sistem ne može da sačuva alat!");
                MessageBox.Show(poruka);
            }
            return uRedu;
        }

        public static void PrikaziAlat(Alat alat, TextBox txtPrikazNaziv, TextBox txtPrikazPro, TextBox txtPrikazVrsta, ComboBox cmbMasina, TextBox txtPrikazCena, CheckBox checkBox1, TextBox txtPrikazStanje)
        {
            txtPrikazNaziv.Text = alat.NazivAlata;
            txtPrikazPro.Text = alat.Proizvodjac;
            txtPrikazVrsta.Text = alat.VrstaAlata;
            cmbMasina.Text = alat.TipMasine;
            txtPrikazCena.Text = alat.Cena.ToString();
            checkBox1.Checked = alat.TrenutnoSeKoristi;
            txtPrikazStanje.Text = alat.NaStanju.ToString();
        }

        public static Alat DozvoliIzmenuAlata(DataGridView dataGridView1)
        {
            Alat a = new Alat();
            try
            {
                a = dataGridView1.CurrentRow.DataBoundItem as Alat;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali alat za izmenu!");
            }
            
            return a;
        }

        public static void IzmeniAlat(Alat alat, TextBox txtNaziv, TextBox txtProizvodjac, TextBox txtVrsta, ComboBox comboBox1, TextBox txtCena, CheckBox checkBox1, TextBox txtStanje)
        {
            alat.NazivAlata = txtNaziv.Text;
            alat.Proizvodjac = txtProizvodjac.Text;
            alat.VrstaAlata = txtVrsta.Text;
            alat.Cena = Convert.ToDouble(txtCena.Text);
            alat.TipMasine = comboBox1.SelectedItem.ToString();
            alat.TrenutnoSeKoristi = checkBox1.Checked;
            alat.NaStanju = Convert.ToInt32(txtStanje.Text);

            komunikacija.ZapamtiAlat(alat);

            MessageBox.Show("Sistem je sacuvao alat.");
        }

        public static bool ValidacijaStanje(TextBox txtStanje)
        {
            int stanje = 0;
            try
            {
                stanje = Convert.ToInt32(txtStanje.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Neispravan unos stanja alata u magacinu!");
                return false;
            }
            if (stanje < 0)
            {
                MessageBox.Show("Stanje alata u magacinu mora biti vece od 0!");
                return false;
            }
            return true;
        }

        public static bool ValidacijaProizvoda(TextBox txtNaziv, TextBox txtKupac)
        {
            bool uRedu = true;
            string poruka = "";

            if (string.IsNullOrEmpty(txtNaziv.Text))
            {
                if (uRedu)
                {
                    poruka += "Niste uneli: naziv proizvoda";
                    uRedu = false;
                }
                else poruka += ", naziv proizvoda";
            }
            if (string.IsNullOrEmpty(txtKupac.Text))
            {
                if (uRedu)
                {
                    poruka += "Niste uneli: kupca";
                    uRedu = false;
                }
                else poruka += ", kupca";
            }

            if (!uRedu)
            {
                MessageBox.Show("Sistem ne može da sačuva proizvod");
                MessageBox.Show(poruka);
            }
            
            return uRedu;
        }

        public static void UnosProizvoda()
        {
            proizvod = komunikacija.UnesiProizvod() as Proizvod;

            if (proizvod == null)
                MessageBox.Show("Sistem ne moze da unese proizvod!");
            else MessageBox.Show("Sistem je uneo proizvod!");
        }

        public static void SacuvajProizvod(TextBox txtNaziv, TextBox txtKupac)
        {
            proizvod.NazivProizvoda = txtNaziv.Text;
            proizvod.Kupac = txtKupac.Text;

            komunikacija.ZapamtiProizvod(proizvod);

            MessageBox.Show("Sistem je sačuvao proizvod.");
        }

        public static bool KreirajNalog(TextBox txtSifra, GroupBox groupBox1, DataGridView dataGridView1)
        {
            nalog = komunikacija.KreirajNalog() as NalogZaNabavku;

            if (nalog == null)
            {
                MessageBox.Show("Sistem ne moze da kreira nalog za nabavku");
                return false;
            }
            else
            {
                txtSifra.Text = nalog.SifraNaloga.ToString();
                groupBox1.Enabled = true;
                dataGridView1.DataSource = nalog.ListaStavki;
                MessageBox.Show("Sistem je kreirao nalog za nabavku");
                return true;
            }
        }

        public static void popuniComboAlata(ComboBox cmbAlat)
        {
            cmbAlat.DataSource = komunikacija.VratiSveAlate();
            cmbAlat.SelectedIndex = -1;
            cmbAlat.Text = "Odaberite alat: ";
        }

        private static bool stavkaValidacija(ComboBox cmbAlat, TextBox txtKolicina)
        {
            if (String.IsNullOrEmpty(txtKolicina.Text))
            {
                MessageBox.Show("Niste ispravno uneli kolicinu!");
                return false;
            }
            try
            {
                int kol = Convert.ToInt32(txtKolicina.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Kolicina mora biti broj!");
                return false;
            }
            return true;
        }
        private static void dodajStavku(ComboBox cmbAlat, TextBox txtKolicina, TextBox txtUkIznos)
        {
            StavkaNaloga sn = new StavkaNaloga();
            sn.SifraNaloga = nalog.SifraNaloga;
            sn.Alat = cmbAlat.SelectedItem as Alat;
            sn.RBStavke = nalog.ListaStavki.Count + 1;
            sn.Kolicina = Convert.ToInt32(txtKolicina.Text);

            foreach (StavkaNaloga s in nalog.ListaStavki)
            {
                if (s.Alat.SifraAlata == sn.Alat.SifraAlata)
                {
                    MessageBox.Show("Vec ste dodali istu komponentu!");
                    s.Kolicina += sn.Kolicina;
                    nalog.UkupnaVrednostNaloga += sn.Kolicina * sn.Alat.Cena;
                    txtUkIznos.Text = nalog.UkupnaVrednostNaloga.ToString("N02");
                    return;
                }
            }

            nalog.UkupnaVrednostNaloga += sn.Kolicina * sn.Alat.Cena;
            txtUkIznos.Text = nalog.UkupnaVrednostNaloga.ToString();
            nalog.ListaStavki.Add(sn);

            txtKolicina.Clear();
        }

        public static void validirajIDodajStavku(ComboBox cmbAlat, TextBox txtKolicina, TextBox txtUkIznos, DataGridView dataGridView1)
        {
            if (cmbAlat.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali alat za nabavku!");
                return;
            }
            int ind = cmbAlat.SelectedIndex;
            if (KontrolerKI.stavkaValidacija(cmbAlat, txtKolicina))
            {
                KontrolerKI.dodajStavku(cmbAlat, txtKolicina, txtUkIznos);
                KontrolerKI.popuniComboAlata(cmbAlat);
                dataGridView1.Refresh();
            }
            else cmbAlat.SelectedIndex = ind;
        }

        public static void obrisiStavku(TextBox txtUkIznos, DataGridView dataGridView1)
        {
            try
            {
                StavkaNaloga sn = dataGridView1.CurrentRow.DataBoundItem as StavkaNaloga;
                nalog.ListaStavki.Remove(sn);
                nalog.UkupnaVrednostNaloga -= sn.Kolicina * sn.Alat.Cena;
                txtUkIznos.Text = nalog.UkupnaVrednostNaloga.ToString();
                int i = 1;
                foreach (StavkaNaloga s in nalog.ListaStavki)
                {
                    s.RBStavke = i;
                    i++;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali stavku za brisanje!");
            }
        }

        public static bool ZapamtiPorudzbinu(DateTimePicker dtpDatum)
        {
            nalog.Datum = dtpDatum.Value;
            nalog.Zaposleni = zaposleni;

            object n = komunikacija.ZapamtiNalog(nalog);

            if (n == null)
            {
                MessageBox.Show("Sistem ne može da zapamti nalog za nabavku");
                return false;
            }
            else
            {
                MessageBox.Show("Sistem je zapamtio nalog za nabavku");
                return true;
            }
        }

        public static void popuniComboZaposlenih(ComboBox cmbZaposleni)
        {
            cmbZaposleni.DataSource = komunikacija.VratiSveZaposlene();
            cmbZaposleni.Text = "Odaberi zaposlenog";
        }

        public static void popuniGrid(ComboBox cmbZaposleni, DataGridView dataGridView1)
        {
                zaposleni = cmbZaposleni.SelectedItem as Zaposleni;
                nalog = new NalogZaNabavku();
                nalog.USLOV = " SifraZaposlenog = " + zaposleni.SifraZaposlenog;
                List<NalogZaNabavku> lista = (List<NalogZaNabavku>)komunikacija.VratiNaloge(nalog);

                dataGridView1.DataSource = lista;

                if (lista.Count == 0)
                {
                    MessageBox.Show("Sistem ne moze da pronadje naloge po zadatoj vrednosti!");
                    return;
                }
        }

        public static bool ObrisiNalog(DataGridView dataGridView)
        {

            try
            {
                NalogZaNabavku n = dataGridView.CurrentRow.DataBoundItem as NalogZaNabavku;
                object o = komunikacija.StornirajNalog(n);
                if (o == null)
                {
                    MessageBox.Show("Sistem ne može da stornira nalog za nabavku");
                    return false;
                }
                else
                {
                    MessageBox.Show("Sistem je stornirao nalog za nabavku");
                    return true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali nalog za brisanje!");
                return false;
            }

        }

        public static void popuniCmbProizvoda(ComboBox comboBox1)
        {
            comboBox1.DataSource = komunikacija.VratiSveProizvode();
            comboBox1.Text = "Odaberite proizvod:";
        }

        public static bool ValidacijaProizvodniProces(ComboBox cmbAlat, ComboBox cmbProizvod, TextBox txtBrOperacije, RichTextBox txtOpis)
        {
            bool uRedu = true;
            string poruka = "";

            if (cmbAlat.SelectedIndex == -1)
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: alat";
                    uRedu = false;
                }
                else poruka += " ,alat";
            }
            if (cmbProizvod.SelectedIndex == -1)
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: proizvod";
                    uRedu = false;
                }
                else poruka += ", proizvod";
            }
            if (string.IsNullOrEmpty(txtBrOperacije.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: broj operacije";
                    uRedu = false;
                }
                else poruka += ", broj operacije";
            }
            if (string.IsNullOrEmpty(txtOpis.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: opis";
                    uRedu = false;
                }
                else poruka += ", opis";
            }
            if (!string.IsNullOrEmpty(txtBrOperacije.Text))
            {
                try
                {
                    int BrOperacije = Convert.ToInt32(txtBrOperacije.Text);
                }
                catch (Exception)
                {
                    poruka += "\nNeispravan unos broja operacije, morate uneti broj!";
                    uRedu = false;
                }

            }
            if (poruka != "")
            {
                MessageBox.Show(poruka);
            }
            return uRedu;
        }

        public static bool UnosProizvodnogProcesa(ComboBox cmbAlat, ComboBox cmbProizvod)
        {
            Alat odabrani_alat = cmbAlat.SelectedItem as Alat;
            Proizvod odabrani_pro = cmbProizvod.SelectedItem as Proizvod;
            TehnoloskiProces pp = new TehnoloskiProces();
            pp.Alat = odabrani_alat;
            pp.Proizvod = odabrani_pro;
            object val = komunikacija.UnesiProizvodniProces(pp);

            if (val == null)
            {
                MessageBox.Show("Sistem ne može da kreira tehnološki proces");
                MessageBox.Show("Тehnološki proces vec postoji za odabrani alat i proizvod!");
                return false;
            }
            else
            {
                MessageBox.Show("Sistem je kreirao tehnološki proces");
                proizvodniProces = pp;
                return true;
            }
        }

        public static void SacuvajProizvodniProces(TextBox txtBrOperacije, RichTextBox txtOpis)
        {
            proizvodniProces.BrojOperacije = Convert.ToInt32(txtBrOperacije.Text);
            proizvodniProces.Opis = txtOpis.Text;

            object pp = komunikacija.ZapamtiProizvodniProces(proizvodniProces);
        }

        public static void vratiProizvodneProcese(DataGridView dataGridView1)
        {
            List<TehnoloskiProces> lista = komunikacija.vratiProizvodneProcese() as List<TehnoloskiProces>;
            foreach (TehnoloskiProces item in lista)
            {
                alat = komunikacija.UcitajAlat(item.Alat) as Alat;
                proizvod = komunikacija.vratiProizvod(item.Proizvod) as Proizvod;
                item.Alat = alat;
                item.Proizvod = proizvod;
            }
            dataGridView1.DataSource = lista;
        }

        public static void PrikaziProizvod(Proizvod proizvod, TextBox txtNazivPro, TextBox txtKupac)
        {
            txtNazivPro.Text = proizvod.NazivProizvoda;
            txtKupac.Text = proizvod.Kupac;
        }

        public static void PrikaziProizvodniProces(TehnoloskiProces tp, TextBox txtBrOp, RichTextBox txtOpis)
        {
            txtBrOp.Text = tp.BrojOperacije.ToString();
            txtOpis.Text = tp.Opis;
        }

        public static void IzmeniProizvodniProces(TextBox txtBrOp, RichTextBox txtOpis, DataGridView dgv)
        {
            bool uRedu = true;
            string poruka = "";
            if (string.IsNullOrEmpty(txtBrOp.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: broj operacije";
                    uRedu = false;
                }
                else poruka += ", broj operacije";
            }
            if (string.IsNullOrEmpty(txtOpis.Text))
            {
                if (uRedu)
                {
                    poruka += "Morate uneti: opis";
                    uRedu = false;
                }
                else poruka += ", opis";
            }
            if (!string.IsNullOrEmpty(txtBrOp.Text))
            {
                try
                {
                    int BrOperacije = Convert.ToInt32(txtBrOp.Text);
                }
                catch (Exception)
                {
                    poruka += "\nNeispravan unos broja operacije, morate uneti broj!";
                    uRedu = false;
                }

            }

            if (uRedu)
            {
                try
                {
                    TehnoloskiProces tp = dgv.CurrentRow.DataBoundItem as TehnoloskiProces;
                    tp.BrojOperacije = Convert.ToInt32(txtBrOp.Text);
                    tp.Opis = txtOpis.Text;

                    komunikacija.ZapamtiProizvodniProces(tp);

                    MessageBox.Show("Sistem je sačuvao izmene na tehnološkom procesu.");
                    dgv.Refresh();
                }
                catch (Exception)
                {
                    MessageBox.Show("Niste odabrali tehnološki proces!");
                }
            }
            else
            {
                MessageBox.Show("Sistem nije sacuvao izmene na tehnoloskom procesu.");
                MessageBox.Show(poruka);
            }
            
        }

        public static void BrisiProizvodniProces(DataGridView dataGridView1)
        {
            
            try 
	        {	        
		        TehnoloskiProces tp = dataGridView1.CurrentRow.DataBoundItem as TehnoloskiProces;
                object o = komunikacija.BrisiProizvodniProces(tp);
                if (o == null)
                {
                    MessageBox.Show("Sistem ne moze da obrise tehnoloski proces!");
                    return;
                }
                else
                {
                    MessageBox.Show("Sistem je obrisao tehnoloski proces!");
                    dataGridView1.Refresh();
                    return;
                }
	        }
	        catch (Exception)
	        {
                MessageBox.Show("Niste odabrali tehnoloski proces!");
                return;
	        }   
        }

        public static void popuniGridPocetno(ComboBox cmbZaposleni, DataGridView dataGridView1)
        {
            zaposleni = cmbZaposleni.SelectedItem as Zaposleni;
            nalog = new NalogZaNabavku();
            nalog.USLOV = " SifraZaposlenog IS NOT NULL";
            List<NalogZaNabavku> lista = (List<NalogZaNabavku>)komunikacija.VratiNaloge(nalog);

            dataGridView1.DataSource = lista;

            if (lista.Count == 0)
            {
                MessageBox.Show("Sistem ne moze da pronadje nijedan nalog!");
                return;
            }
        }
    }       
}
