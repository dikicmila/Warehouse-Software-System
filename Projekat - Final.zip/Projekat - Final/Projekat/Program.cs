﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Projekat
{

    class A
    {
        public virtual void print() {
            Console.WriteLine("A");
        }

    }

    class B : A
    {
        public override void print()
        {
            Console.WriteLine("B");
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            A a = new A();
            A ab = new B();
            B b = new B();
            a.print();
            ab.print();
            b.print();
        }
    }
}
