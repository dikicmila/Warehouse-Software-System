﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.ComponentModel;

namespace Biblioteka
{
    [Serializable]
    public class Zaposleni : OpstiDomenskiObjekat
    {

        int sifraZaposlenog;
        string ime;
        string prezime;
        string telefon;
        string mestoPrebivalista;
        string korisnickoIme;
        string sifra;


        public override string ToString()
        {
            return Ime + " " + Prezime;
        } 

        public string Sifra
        {
            get { return sifra; }
            set { sifra = value; }
        }

        public string KorisnickoIme
        {
            get { return korisnickoIme; }
            set { korisnickoIme = value; }
        }


        public string MestoPrebivalista
        {
            get { return mestoPrebivalista; }
            set { mestoPrebivalista = value; }
        }

        public string Telefon
        {
            get { return telefon; }
            set { telefon = value; }
        }

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public int SifraZaposlenog
        {
            get { return sifraZaposlenog; }
            set { sifraZaposlenog = value; }
        }

        //ODO
        [Browsable(false)]
        public string nazivTabele
        {
            get { return "Zaposleni"; }
        }
        [Browsable(false)]
        public string primarniKljuc
        {
            get { return "SifraZaposlenog"; }
        }
        [Browsable(false)]
        public string uslovPrimarni
        {
            get { return " SifraZaposlenog = " + SifraZaposlenog + " "; }
        }
        [Browsable(false)]
        public string uslovOstalo
        {
            get { return " KorisnickoIme = '" + KorisnickoIme + "' and Sifra = '" + Sifra + "'"; }
        }
        [Browsable(false)]
        public string izmena
        {
            get { return ""; }
        }
        [Browsable(false)]
        public string unos
        {
            get { return ""; }
        }

        public OpstiDomenskiObjekat procitaj(DataRow red)
        {
            Zaposleni z = new Zaposleni();
            z.SifraZaposlenog = Convert.ToInt32(red["SifraZaposlenog"]);
            z.Ime = red["Ime"].ToString();
            z.Prezime = red["Prezime"].ToString();
            z.Telefon = red["BrojTelefona"].ToString();
            z.mestoPrebivalista = red["MestoPrebivalista"].ToString();
            z.KorisnickoIme = red["KorisnickoIme"].ToString();
            z.Sifra = red["Sifra"].ToString();

            return z;
        }
    }
}
