﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;

namespace Biblioteka
{
    [Serializable]
    public class StavkaNaloga : OpstiDomenskiObjekat
    {
        int sifraNaloga;

        public int SifraNaloga
        {
            get { return sifraNaloga; }
            set { sifraNaloga = value; }
        }

        int rBStavke;

        public int RBStavke
        {
            get { return rBStavke; }
            set { rBStavke = value; }
        }

        double kolicina;

        public double Kolicina
        {
            get { return kolicina; }
            set { kolicina = value; }
        }

        bool hitno;

        public bool Hitno
        {
            get { return hitno; }
            set { hitno = value; }
        }

        Alat alat;

        public Alat Alat
        {
            get { return alat; }
            set { alat = value; }
        }

        //ODO

        [Browsable(false)]
        public string nazivTabele
        {
            get { return "StavkaNaloga"; }
        }

        [Browsable(false)]
        public string primarniKljuc
        {
            get { return ""; }
        }

        [Browsable(false)]
        public string uslovPrimarni
        {
            get { return "SifraNaloga = " + SifraNaloga + " and RBStavke = " + RBStavke; }
        }
        
        [Browsable(false)]
        public string USLOV = "";

        [Browsable(false)]
        public string uslovOstalo
        {
            get { return USLOV; }
        }

        int bool2bit(bool p)
        {
            if (p)
                return 1;
            return 0;
        }

        [Browsable(false)]
        public string izmena
        {
            get
            {
                return "KolicinaZaNabavku = " + Kolicina + ", Hitno = " + bool2bit(Hitno) + ", SifraAlata = " + Alat.SifraAlata + " ";
            }
        }

        [Browsable(false)]
        public string unos
        {
            get { return "(SifraNaloga,RBStavke) values (" + SifraNaloga + "," + RBStavke + ")"; }
        }



        public OpstiDomenskiObjekat procitaj(DataRow red)
        {
            StavkaNaloga sn = new StavkaNaloga();

            sn.sifraNaloga = Convert.ToInt32(red["SifraNaloga"]);
            sn.RBStavke = Convert.ToInt32(red["RBStavke"]);
            sn.Kolicina = Convert.ToDouble(red["KolicinaZaNabavku"]);
            sn.Hitno = Convert.ToInt32(red["Hitno"]) == 0 ? false : true;
            sn.Alat = new Alat();
            sn.Alat.SifraAlata = Convert.ToInt32(red["SifraAlata"]);

            return sn;
        }
    }
}
