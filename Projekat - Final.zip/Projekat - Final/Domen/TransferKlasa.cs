﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    public enum Operacije { Kraj = 1, Login, UnesiAlat, ZapamtiAlat, PretraziAlat, VratiSveAlate, UcitajAlat, UnesiProizvod, ZapamtiProizvod, KreirajNalog, ZapamtiNalog, VratiSveZaposlene, VratiNaloge, StornirajNalog, VratiSveProizvode, UnesiProizvodniProces, ZapamtiProizvodniProces, VratiProizvodneProcese, VratiProizvod, BrisiProizvodniProces }
    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public Object TransferObjekat;
        public Object Rezultat;
    }
}
