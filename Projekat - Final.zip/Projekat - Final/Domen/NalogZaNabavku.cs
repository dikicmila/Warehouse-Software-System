﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.ComponentModel;

namespace Biblioteka
{
    [Serializable]
    public class NalogZaNabavku : OpstiDomenskiObjekat
    {
        public NalogZaNabavku()
        {
            listaStavki = new BindingList<StavkaNaloga>();
            ukupnaVrednostNaloga = 0;
        }

        int sifraNaloga;

        public int SifraNaloga
        {
            get { return sifraNaloga; }
            set { sifraNaloga = value; }
        }

        DateTime datum;

        public DateTime Datum
        {
            get { return datum; }
            set { datum = value; }
        }

        

        BindingList<StavkaNaloga> listaStavki;

        public BindingList<StavkaNaloga> ListaStavki
        {
            get { return listaStavki; }
            set { listaStavki = value; }
        }
        
        double ukupnaVrednostNaloga;

        public double UkupnaVrednostNaloga
        {
            get { return ukupnaVrednostNaloga; }
            set { ukupnaVrednostNaloga = value; }
        }
        
        bool ponisten;
        [Browsable(false)]
        public bool Ponisten
        {
            get { return ponisten; }
            set { ponisten = value; }
        }

        
        Zaposleni zaposleni;
        [Browsable(false)]
        public Zaposleni Zaposleni
        {
            get { return zaposleni; }
            set { zaposleni = value; }
        }

        #region ODO
        [Browsable(false)]
        public string nazivTabele
        {
            get { return "NalogZaNabavku"; }
        }
        [Browsable(false)]
        public string primarniKljuc
        {
            get { return "SifraNaloga"; }
        }
        [Browsable(false)]
        public string uslovPrimarni
        {
            get { return "SifraNaloga = " + SifraNaloga; }
        }
        [Browsable(false)]
        public string USLOV = "";
        [Browsable(false)]
        public string uslovOstalo
        {
            get { return USLOV; }
        }

        int bool2bit(bool p)
        {
            if (p)
                return 1;
            return 0;
        }

        [Browsable(false)]
        public string izmena
        {
            get
            {
                return " Datum = '" + Datum.ToString("yyyy-MM-dd") + "', Ponisten = " + bool2bit(Ponisten)
                    + ", UkupnaVrednostNaloga = " + UkupnaVrednostNaloga + ", SifraZaposlenog = " + Zaposleni.SifraZaposlenog + " ";
            }
        }
        [Browsable(false)]
        public string unos
        {
            get { return "(SifraNaloga) values (" + SifraNaloga + ")"; }
        }

        public OpstiDomenskiObjekat procitaj(DataRow red)
        {
            NalogZaNabavku n = new NalogZaNabavku();
            n.SifraNaloga = Convert.ToInt32(red["SifraNaloga"]);
            n.Datum = Convert.ToDateTime(red["Datum"]);
            n.Ponisten = Convert.ToInt32(red["Ponisten"]) == 0 ? false : true;
            n.UkupnaVrednostNaloga = Convert.ToDouble(red["UkupnaVrednostNaloga"]);
            n.Zaposleni = new Zaposleni();
            n.Zaposleni.SifraZaposlenog = Convert.ToInt32(red["SifraZaposlenog"]);

            return n;
        }

        #endregion
    }
}
