﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;

namespace Biblioteka
{
    [Serializable]
    public class TehnoloskiProces : OpstiDomenskiObjekat
    {
        Proizvod proizvod;
        public Proizvod Proizvod
        {
            get { return proizvod; }
            set { proizvod = value; }
        }

        Alat alat;
        public Alat Alat
        {
            get { return alat; }
            set { alat = value; }
        }

        int brojOperacije;

        public int BrojOperacije
        {
            get { return brojOperacije; }
            set { brojOperacije = value; }
        }

        string opis;

        public string Opis
        {
            get { return opis; }
            set { opis = value; }
        }
        public override string ToString()
        {
            return "Alat: " + Alat.ToString() + " - Proizvod: " + Proizvod.ToString() + " (Broj operacije: " + BrojOperacije + ")";
        }

        #region ODO
        [Browsable(false)]
        public string nazivTabele
        {
            get { return "ProizvodniProces"; }
        }

        [Browsable(false)]
        public string primarniKljuc
        {
            get { return ""; }
        }

        [Browsable(false)]
        public string uslovPrimarni
        {
            get { return " SifraAlata = " + Alat.SifraAlata + " and SifraProizvoda = " + Proizvod.SifraProizvoda; }
        }

        [Browsable(false)]
        public string uslovOstalo
        {
            get { return ""; }
        }

        [Browsable(false)]
        public string izmena
        {
            get
            {
                return " BrojOperacije = " + BrojOperacije + ", Opis = '" + Opis + "' ";
            }
        }

        [Browsable(false)]
        public string unos
        {
            get { return "(SifraAlata,SifraProizvoda) values (" + Alat.SifraAlata + "," + Proizvod.SifraProizvoda + ")"; }
        }



        public OpstiDomenskiObjekat procitaj(DataRow red)
        {
            TehnoloskiProces tp = new TehnoloskiProces();
            tp.Proizvod = new Proizvod();
            tp.Proizvod.SifraProizvoda = Convert.ToInt32(red["SifraProizvoda"]);
            tp.Alat = new Alat();
            tp.Alat.SifraAlata = Convert.ToInt32(red["SifraAlata"]);
            tp.BrojOperacije = Convert.ToInt32(red["BrojOperacije"]);
            tp.Opis = red["Opis"].ToString();

            return tp;
        }

        #endregion
    }
}
