﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;

namespace Biblioteka
{
    [Serializable]
    public class Alat : OpstiDomenskiObjekat
    {
        int sifraAlata;
        string nazivAlata;
        string proizvodjac;
        string vrstaAlata;
        bool trenutnoSeKoristi;
        int naStanju;
        string tipMasine;
        double cena;

        public override string ToString()
        {
            return NazivAlata + " (" + VrstaAlata + ")";
        }
        
        [Browsable(false)]
        public int SifraAlata
        {
            get { return sifraAlata; }
            set { sifraAlata = value; }
        }

        public string NazivAlata
        {
            get { return nazivAlata; }
            set { nazivAlata = value; }
        }

        public string VrstaAlata
        {
            get { return vrstaAlata; }
            set { vrstaAlata = value; }
        }

        public bool TrenutnoSeKoristi
        {
            get { return trenutnoSeKoristi; }
            set { trenutnoSeKoristi = value; }
        }

        public int NaStanju
        {
            get { return naStanju; }
            set { naStanju = value; }
        }

        public string TipMasine
        {
            get { return tipMasine; }
            set { tipMasine = value; }
        }

        public string Proizvodjac
        {
            get { return proizvodjac; }
            set { proizvodjac = value; }
        }

        public double Cena
        {
            get { return cena; }
            set { cena = value; }
        }

        // ODO 

        [Browsable(false)]
        public string nazivTabele
        {
            get { return "Alat"; }
        }

        [Browsable(false)]
        public string primarniKljuc
        {
            get { return "SifraAlata"; }
        }

        [Browsable(false)]
        public string uslovPrimarni
        {
            get { return "SifraAlata = " + SifraAlata; }
        }
        [Browsable(false)]
        public string uslov = " NazivAlata is null ";
        [Browsable(false)]
        public string uslovOstalo
        {
            get { return uslov; }
        }

        int bool2bit(bool p)
        {
            if (p)
                return 1;
            return 0;
        }

        [Browsable(false)]
        public string izmena
        {
            get { return "NazivAlata = '" + NazivAlata + "', Proizvodjac = '" + Proizvodjac + "', VrstaAlata = '" 
                + VrstaAlata + "', TrenutnoSeKoristi = " + bool2bit(TrenutnoSeKoristi) + ", NaStanju = " 
                + NaStanju + ", TipMasine = '" + TipMasine + "', Cena = " + Cena + " "; }
        }

        [Browsable(false)]
        public string unos
        {
            get { return "(SifraAlata) values (" + SifraAlata + ")"; }
        }

       

        public OpstiDomenskiObjekat procitaj(DataRow red)
        {
            Alat a = new Alat();
            a.SifraAlata = Convert.ToInt32(red["SifraAlata"]);
            a.NazivAlata = red["NazivAlata"].ToString();
            a.Proizvodjac = red["Proizvodjac"].ToString();
            a.VrstaAlata = red["VrstaAlata"].ToString();
            a.TrenutnoSeKoristi = Convert.ToInt32(red["TrenutnoSeKoristi"]) == 0 ? false : true;
            a.NaStanju = Convert.ToInt32(red["NaStanju"]);
            a.TipMasine = red["TipMasine"].ToString();
            a.Cena = Convert.ToDouble(red["Cena"]);

            return a;
        }
    }
}
