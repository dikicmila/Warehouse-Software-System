﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;

namespace Biblioteka
{
    [Serializable]
    public class Proizvod : OpstiDomenskiObjekat
    {
        int sifraProizvoda;

        public int SifraProizvoda
        {
            get { return sifraProizvoda; }
            set { sifraProizvoda = value; }
        }

        string nazivProizvoda;

        public string NazivProizvoda
        {
            get { return nazivProizvoda; }
            set { nazivProizvoda = value; }
        }

        string kupac;

        public string Kupac
        {
            get { return kupac; }
            set { kupac = value; }
        }


        public override string ToString()
        {
            return NazivProizvoda + " (" + Kupac + ")";
        }

        //ODO

        [Browsable(false)]
        public string nazivTabele
        {
            get { return "Proizvod"; }
        }
        [Browsable(false)]
        public string primarniKljuc
        {
            get { return "SifraProizvoda"; }
        }

        [Browsable(false)]
        public string uslovPrimarni
        {
            get { return "SifraProizvoda = " + SifraProizvoda; }
        }

        [Browsable(false)]
        public string uslovOstalo
        {
            get { return ""; }
        }

        [Browsable(false)]
        public string izmena
        {
            get { return "NazivProizvoda = '" + NazivProizvoda + "', Kupac = '" + Kupac + "' "; }
        }

        [Browsable(false)]
        public string unos
        {
            get { return "(SifraProizvoda) values (" + SifraProizvoda + ")"; }
        }


        public OpstiDomenskiObjekat procitaj(DataRow red)
        {
            Proizvod p = new Proizvod();
            p.SifraProizvoda = Convert.ToInt32(red["SifraProizvoda"]);
            p.NazivProizvoda = red["NazivProizvoda"].ToString();
            p.Kupac = red["Kupac"].ToString();

            return p;
        }
    }
}
