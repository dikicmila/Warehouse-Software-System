﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Server
{
    public partial class FormaServera : Form
    {
        Server s;
        public FormaServera()
        {
            InitializeComponent();
        }

        private void FormaServera_Load(object sender, EventArgs e)
        {
        }

        private void btnPokreni_Click(object sender, EventArgs e)
        {
            s = new Server();
            if (s.PokreniServer())
            {
                lblStatus.Text = "Server je pokrenut";
                lblStatus.ForeColor = Color.Green;
                btnPokreni.Enabled = false;
                btnZaustavi.Enabled = true;
            }
        }

        private void btnZaustavi_Click(object sender, EventArgs e)
        {
            if (Server.listaTokova.Count > 0)
            {
                MessageBox.Show("Server ne moze biti ugasen! Postoje korisnici na sistemu!");
                return;
            }
            if (s.ZaustaviServer())
            {
                lblStatus.Text = "Server nije pokrenut";
                lblStatus.ForeColor = Color.Red;
                btnPokreni.Enabled = true;
                btnZaustavi.Enabled = false;
            }
        }
    }
}
