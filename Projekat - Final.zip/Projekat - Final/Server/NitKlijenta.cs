﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using Biblioteka;

using Server.SistemskeOperacije.AlatSO;
using Server.SistemskeOperacije.ZaposleniSO;
using Server.SistemskeOperacije.ProizvodSO;
using Server.SistemskeOperacije.NalogSO;
using Server.SistemskeOperacije.ProizvodniProcesSO;

namespace Server
{
    public class NitKlijenta
    {
        NetworkStream tok;
        BinaryFormatter formater;

        public NitKlijenta(NetworkStream tok)
        {
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradi;
            new Thread(ts).Start();
        }

        void obradi()
        {
            try
            {
                int operacija = 0;
                while (operacija != (int)Operacije.Kraj)
                {
                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;
                    switch (transfer.Operacija)
                    {
                        case Operacije.Login:
                            Login login = new Login();
                            transfer.Rezultat = login.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.UnesiAlat:
                            UnesiAlat unesi = new UnesiAlat();
                            transfer.Rezultat = unesi.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.ZapamtiAlat:
                            ZapamtiAlat zapamti = new ZapamtiAlat();
                            transfer.Rezultat = zapamti.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.PretraziAlat:
                            PretraziAlat pretrazi = new PretraziAlat();
                            transfer.Rezultat = pretrazi.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiSveAlate:
                            VratiSveAlate vrati = new VratiSveAlate();
                            transfer.Rezultat = vrati.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.UcitajAlat:
                            UcitajAlat ucitaj = new UcitajAlat();
                            transfer.Rezultat = ucitaj.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.UnesiProizvod:
                            UnesiProizvod unesiPro = new UnesiProizvod();
                            transfer.Rezultat = unesiPro.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.ZapamtiProizvod:
                            ZapamtiProizvod zapamtiPro = new ZapamtiProizvod();
                            transfer.Rezultat = zapamtiPro.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.KreirajNalog:
                            KreirajNalog kreirajNalog = new KreirajNalog();
                            transfer.Rezultat = kreirajNalog.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.ZapamtiNalog:
                            SacuvajNalog sacuvajNalog = new SacuvajNalog();
                            transfer.Rezultat = sacuvajNalog.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiSveZaposlene:
                            VratiSveZaposlene vratiZap = new VratiSveZaposlene();
                            transfer.Rezultat = vratiZap.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiNaloge:
                            VratiNalogeZaposlenog vratiNaloge = new VratiNalogeZaposlenog();
                            transfer.Rezultat = vratiNaloge.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.StornirajNalog:
                            StornirajNalog sn = new StornirajNalog();
                            transfer.Rezultat = sn.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiSveProizvode:
                            VratiProizvode vp = new VratiProizvode();
                            transfer.Rezultat = vp.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.UnesiProizvodniProces:
                            UnesiProizvodniProces upp = new UnesiProizvodniProces();
                            transfer.Rezultat = upp.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.ZapamtiProizvodniProces:
                            ZapamtiProizvodniProces zpp = new ZapamtiProizvodniProces();
                            transfer.Rezultat = zpp.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiProizvodneProcese:
                            VratiProizvodneProcese vpp = new VratiProizvodneProcese();
                            transfer.Rezultat = vpp.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiProizvod:
                            VratiProizvod vpr = new VratiProizvod();
                            transfer.Rezultat = vpr.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.BrisiProizvodniProces:
                            BrisiProizvodniProces bpr = new BrisiProizvodniProces();
                            transfer.Rezultat = bpr.IzvrsiSO(transfer.TransferObjekat as OpstiDomenskiObjekat);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.Kraj:
                            operacija = 1;
                            Server.listaTokova.Remove(tok);
                            break;   
                        default:
                            break;
                    }
                }
            }
            catch (Exception)
            {
                Server.listaTokova.Remove(tok);
            }
        }
    }
}
