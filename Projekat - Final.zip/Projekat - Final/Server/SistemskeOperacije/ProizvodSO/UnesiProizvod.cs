﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.ProizvodSO
{
    public class UnesiProizvod : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            Proizvod p = new Proizvod();
            p.SifraProizvoda = Broker.dajSesiju().vratiSifru(p);
            Broker.dajSesiju().kreiraj(p);
            return p;
        }
    }
}
