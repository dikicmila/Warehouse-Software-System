﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
namespace Server.SistemskeOperacije.ProizvodSO
{
    public class VratiProizvod : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            return Broker.dajSesiju().vratiZaUslovPrimarni(odo) as Proizvod;
        }
    }
}
