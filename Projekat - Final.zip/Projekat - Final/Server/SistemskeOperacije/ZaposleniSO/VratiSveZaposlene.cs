﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
namespace Server.SistemskeOperacije.ZaposleniSO
{
    public class VratiSveZaposlene : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(Biblioteka.OpstiDomenskiObjekat odo)
        {
            return Broker.dajSesiju().vratiSve(odo).OfType<Zaposleni>().ToList<Zaposleni>();
        }
    }
}
