﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.ZaposleniSO
{
    public class Login : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            return Broker.dajSesiju().vratiZaUslovOstalo(odo) as Zaposleni;
        }
    }
}
