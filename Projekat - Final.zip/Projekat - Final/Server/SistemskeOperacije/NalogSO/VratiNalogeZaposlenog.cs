﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.NalogSO
{
    public class VratiNalogeZaposlenog : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            return Broker.dajSesiju().vratiSveZaUslovOstalo(odo).OfType<NalogZaNabavku>().ToList<NalogZaNabavku>();
        }
    }
}
