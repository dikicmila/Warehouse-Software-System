﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
namespace Server.SistemskeOperacije.NalogSO
{
    public class KreirajNalog : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            NalogZaNabavku nalog = new NalogZaNabavku();
            nalog.SifraNaloga = Broker.dajSesiju().vratiSifru(nalog);
            Broker.dajSesiju().kreiraj(nalog);
            return nalog;
        }
    }
}
