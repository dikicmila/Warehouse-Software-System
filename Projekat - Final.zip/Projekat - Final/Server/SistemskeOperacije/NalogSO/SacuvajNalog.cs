﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
namespace Server.SistemskeOperacije.NalogSO
{
    public class SacuvajNalog : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(Biblioteka.OpstiDomenskiObjekat odo)
        {
            NalogZaNabavku nalog= odo as NalogZaNabavku;
            Broker.dajSesiju().izmeniUslovPrimarni(nalog);

            StavkaNaloga sn = new StavkaNaloga();
            sn.USLOV = " SifraNaloga = " + nalog.SifraNaloga;
            Broker.dajSesiju().obrisiZaUslovOstalo(sn);

            foreach (StavkaNaloga s in nalog.ListaStavki)
            {
                Broker.dajSesiju().kreiraj(s);
                Broker.dajSesiju().izmeniUslovPrimarni(s);
            }

            return true;
        }
    }
}
