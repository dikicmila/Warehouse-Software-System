﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.NalogSO
{
    public class StornirajNalog : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            NalogZaNabavku nalog = odo as NalogZaNabavku;

            StavkaNaloga sn = new StavkaNaloga();
            sn.USLOV = " SifraNaloga = " + nalog.SifraNaloga;
            Broker.dajSesiju().obrisiZaUslovOstalo(sn);

            Broker.dajSesiju().obrisiZaUslovPrimarni(nalog);

            return true;
        }
    }
}
