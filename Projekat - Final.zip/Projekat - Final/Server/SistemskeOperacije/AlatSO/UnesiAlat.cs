﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.AlatSO
{
    public class UnesiAlat : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            Alat a = new Alat();
            a.SifraAlata = Broker.dajSesiju().vratiSifru(a);
            Broker.dajSesiju().kreiraj(a);
            return a;
        }
    }
}
