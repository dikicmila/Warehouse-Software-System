﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server.SistemskeOperacije.AlatSO
{
    public class ZapamtiAlat : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(Biblioteka.OpstiDomenskiObjekat odo)
        {
            return Broker.dajSesiju().izmeniUslovPrimarni(odo);
        }
    }
}
