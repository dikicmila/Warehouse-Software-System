﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.ProizvodniProcesSO
{
    public class BrisiProizvodniProces : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            TehnoloskiProces tp = odo as TehnoloskiProces;
            Broker.dajSesiju().obrisiZaUslovPrimarni(tp);
            return tp;
        }
    }
}
