﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
namespace Server.SistemskeOperacije.ProizvodniProcesSO
{
    public class UnesiProizvodniProces : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(Biblioteka.OpstiDomenskiObjekat odo)
        {
            if (Broker.dajSesiju().vratiZaUslovPrimarni(odo) == null)
            {
                TehnoloskiProces tp = new TehnoloskiProces();
                tp.Alat = ((TehnoloskiProces)odo).Alat;
                tp.Proizvod = ((TehnoloskiProces)odo).Proizvod;
                return Broker.dajSesiju().kreiraj(tp);
            }
            return null;
                
        }
    }
}
