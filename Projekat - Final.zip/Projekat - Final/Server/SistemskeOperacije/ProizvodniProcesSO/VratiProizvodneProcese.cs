﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;

namespace Server.SistemskeOperacije.ProizvodniProcesSO
{
    public class VratiProizvodneProcese : OpstaSO
    {
        public override object IzvrsiKonkretnuSO(OpstiDomenskiObjekat odo)
        {
            return Broker.dajSesiju().vratiSve(odo).OfType<TehnoloskiProces>().ToList<TehnoloskiProces>();
        }
    }
}
