﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net.Sockets;
using Biblioteka;

namespace KontrolerAplikacioneLogike
{
    public class Komunikacija
    {
        BinaryFormatter formater;
        TcpClient klijent;
        NetworkStream tok;

        public bool poveziNaServer()
        {
            try
            {
                klijent = new TcpClient("localhost",20000);
                tok = klijent.GetStream();
                formater = new BinaryFormatter();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void Kraj()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.Kraj;
            formater.Serialize(tok,transfer);
        }

        public Object Login(Zaposleni z)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.Login;
            transfer.TransferObjekat = z;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat;
        }

        public Object UnesiAlat()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.UnesiAlat;
            transfer.TransferObjekat = new Alat();
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object ZapamtiAlat(Alat a)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiAlat;
            transfer.TransferObjekat = a;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object PretraziAlat(Alat a)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.PretraziAlat;
            transfer.TransferObjekat = a;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object UcitajAlat(Alat a)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.UcitajAlat;
            transfer.TransferObjekat = a;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object VratiSveAlate()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiSveAlate;
            transfer.TransferObjekat = new Alat();
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object UnesiProizvod()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.UnesiProizvod;
            transfer.TransferObjekat = new Proizvod();
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object ZapamtiProizvod(Proizvod proizvod)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiProizvod;
            transfer.TransferObjekat = proizvod;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object KreirajNalog()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.KreirajNalog;
            transfer.TransferObjekat = new NalogZaNabavku();
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object ZapamtiNalog(NalogZaNabavku nalog)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiNalog;
            transfer.TransferObjekat = nalog;
            formater.Serialize(tok, transfer);

            return (formater.Deserialize(tok) as TransferKlasa).Rezultat;
        }

        public Object VratiSveZaposlene()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiSveZaposlene;
            transfer.TransferObjekat = new Zaposleni();
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object VratiNaloge(NalogZaNabavku nalog)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiNaloge;
            transfer.TransferObjekat = nalog;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object StornirajNalog(NalogZaNabavku nalog)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.StornirajNalog;
            transfer.TransferObjekat = nalog;
            formater.Serialize(tok, transfer);

            return (formater.Deserialize(tok) as TransferKlasa).Rezultat;
        }

        public Object VratiSveProizvode()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiSveProizvode;
            transfer.TransferObjekat = new Proizvod();
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public Object UnesiProizvodniProces(TehnoloskiProces tp)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.UnesiProizvodniProces;
            transfer.TransferObjekat = tp;
            formater.Serialize(tok, transfer);

            object rez =  ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
            return rez;
        }


        public object ZapamtiProizvodniProces(TehnoloskiProces proizvodniProces)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.ZapamtiProizvodniProces;
            transfer.TransferObjekat = proizvodniProces;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public object vratiProizvodneProcese()
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiProizvodneProcese;
            transfer.TransferObjekat = new TehnoloskiProces();
            formater.Serialize(tok, transfer);

            object rez = ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
            return rez;
        }

        public object vratiProizvod(Proizvod proizvod)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.VratiProizvod;
            transfer.TransferObjekat = proizvod;
            formater.Serialize(tok, transfer);

            return ((TransferKlasa)formater.Deserialize(tok)).Rezultat;
        }

        public object BrisiProizvodniProces(TehnoloskiProces tp)
        {
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.BrisiProizvodniProces;
            transfer.TransferObjekat = tp;
            formater.Serialize(tok, transfer);

            return (formater.Deserialize(tok) as TransferKlasa).Rezultat;
        }

    }
}
