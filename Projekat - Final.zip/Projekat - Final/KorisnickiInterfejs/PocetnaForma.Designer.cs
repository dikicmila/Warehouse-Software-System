﻿namespace KorisnickiInterfejs
{
    partial class PocetnaForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblVreme = new System.Windows.Forms.Label();
            this.lblDatum = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblTelefon = new System.Windows.Forms.Label();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.lblIme = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.alatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unesiAlatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pretragaAlataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proizvodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unosProizvodaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nalogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unosNalogaZaNabavkuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brisanjeNalogaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proizvodniProcesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.izmenaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brisanjeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblVreme);
            this.groupBox1.Controls.Add(this.lblDatum);
            this.groupBox1.Controls.Add(this.lblUser);
            this.groupBox1.Controls.Add(this.lblTelefon);
            this.groupBox1.Controls.Add(this.lblPrezime);
            this.groupBox1.Controls.Add(this.lblIme);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(413, 217);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ZAPOSLENI";
            // 
            // lblVreme
            // 
            this.lblVreme.AutoSize = true;
            this.lblVreme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVreme.Location = new System.Drawing.Point(143, 184);
            this.lblVreme.Name = "lblVreme";
            this.lblVreme.Size = new System.Drawing.Size(60, 20);
            this.lblVreme.TabIndex = 11;
            this.lblVreme.Text = "label12";
            // 
            // lblDatum
            // 
            this.lblDatum.AutoSize = true;
            this.lblDatum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatum.Location = new System.Drawing.Point(143, 153);
            this.lblDatum.Name = "lblDatum";
            this.lblDatum.Size = new System.Drawing.Size(60, 20);
            this.lblDatum.TabIndex = 10;
            this.lblDatum.Text = "label11";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(143, 124);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(60, 20);
            this.lblUser.TabIndex = 9;
            this.lblUser.Text = "label10";
            // 
            // lblTelefon
            // 
            this.lblTelefon.AutoSize = true;
            this.lblTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefon.Location = new System.Drawing.Point(143, 93);
            this.lblTelefon.Name = "lblTelefon";
            this.lblTelefon.Size = new System.Drawing.Size(51, 20);
            this.lblTelefon.TabIndex = 8;
            this.lblTelefon.Text = "label9";
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrezime.Location = new System.Drawing.Point(143, 63);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(51, 20);
            this.lblPrezime.TabIndex = 7;
            this.lblPrezime.Text = "label8";
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIme.Location = new System.Drawing.Point(143, 34);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(51, 20);
            this.lblIme.TabIndex = 6;
            this.lblIme.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Vreme prijave:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Datum prijave:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Korisnicko ime:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Broj telefona:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prezime:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alatToolStripMenuItem,
            this.proizvodToolStripMenuItem,
            this.nalogToolStripMenuItem,
            this.proizvodniProcesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(438, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // alatToolStripMenuItem
            // 
            this.alatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unesiAlatToolStripMenuItem,
            this.pretragaAlataToolStripMenuItem});
            this.alatToolStripMenuItem.Name = "alatToolStripMenuItem";
            this.alatToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.alatToolStripMenuItem.Text = "Alat";
            this.alatToolStripMenuItem.Click += new System.EventHandler(this.alatToolStripMenuItem_Click);
            // 
            // unesiAlatToolStripMenuItem
            // 
            this.unesiAlatToolStripMenuItem.Name = "unesiAlatToolStripMenuItem";
            this.unesiAlatToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.unesiAlatToolStripMenuItem.Text = "Unesi Alat";
            this.unesiAlatToolStripMenuItem.Click += new System.EventHandler(this.unesiAlatToolStripMenuItem_Click);
            // 
            // pretragaAlataToolStripMenuItem
            // 
            this.pretragaAlataToolStripMenuItem.Name = "pretragaAlataToolStripMenuItem";
            this.pretragaAlataToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pretragaAlataToolStripMenuItem.Text = "Pretraga alata";
            this.pretragaAlataToolStripMenuItem.Click += new System.EventHandler(this.pretragaAlataToolStripMenuItem_Click);
            // 
            // proizvodToolStripMenuItem
            // 
            this.proizvodToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosProizvodaToolStripMenuItem});
            this.proizvodToolStripMenuItem.Name = "proizvodToolStripMenuItem";
            this.proizvodToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.proizvodToolStripMenuItem.Text = "Proizvod";
            // 
            // unosProizvodaToolStripMenuItem
            // 
            this.unosProizvodaToolStripMenuItem.Name = "unosProizvodaToolStripMenuItem";
            this.unosProizvodaToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.unosProizvodaToolStripMenuItem.Text = "Unos proizvoda";
            this.unosProizvodaToolStripMenuItem.Click += new System.EventHandler(this.unosProizvodaToolStripMenuItem_Click);
            // 
            // nalogToolStripMenuItem
            // 
            this.nalogToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosNalogaZaNabavkuToolStripMenuItem,
            this.brisanjeNalogaToolStripMenuItem});
            this.nalogToolStripMenuItem.Name = "nalogToolStripMenuItem";
            this.nalogToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.nalogToolStripMenuItem.Text = "Nabavka";
            // 
            // unosNalogaZaNabavkuToolStripMenuItem
            // 
            this.unosNalogaZaNabavkuToolStripMenuItem.Name = "unosNalogaZaNabavkuToolStripMenuItem";
            this.unosNalogaZaNabavkuToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.unosNalogaZaNabavkuToolStripMenuItem.Text = "Unos naloga za nabavku";
            this.unosNalogaZaNabavkuToolStripMenuItem.Click += new System.EventHandler(this.unosNalogaZaNabavkuToolStripMenuItem_Click);
            // 
            // brisanjeNalogaToolStripMenuItem
            // 
            this.brisanjeNalogaToolStripMenuItem.Name = "brisanjeNalogaToolStripMenuItem";
            this.brisanjeNalogaToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.brisanjeNalogaToolStripMenuItem.Text = "Pretraga naloga";
            this.brisanjeNalogaToolStripMenuItem.Click += new System.EventHandler(this.brisanjeNalogaToolStripMenuItem_Click);
            // 
            // proizvodniProcesToolStripMenuItem
            // 
            this.proizvodniProcesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosToolStripMenuItem,
            this.izmenaToolStripMenuItem,
            this.brisanjeToolStripMenuItem});
            this.proizvodniProcesToolStripMenuItem.Name = "proizvodniProcesToolStripMenuItem";
            this.proizvodniProcesToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.proizvodniProcesToolStripMenuItem.Text = "Proizvodni proces";
            // 
            // unosToolStripMenuItem
            // 
            this.unosToolStripMenuItem.Name = "unosToolStripMenuItem";
            this.unosToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.unosToolStripMenuItem.Text = "Unos";
            this.unosToolStripMenuItem.Click += new System.EventHandler(this.unosToolStripMenuItem_Click);
            // 
            // izmenaToolStripMenuItem
            // 
            this.izmenaToolStripMenuItem.Name = "izmenaToolStripMenuItem";
            this.izmenaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.izmenaToolStripMenuItem.Text = "Izmena";
            this.izmenaToolStripMenuItem.Click += new System.EventHandler(this.izmenaToolStripMenuItem_Click);
            // 
            // brisanjeToolStripMenuItem
            // 
            this.brisanjeToolStripMenuItem.Name = "brisanjeToolStripMenuItem";
            this.brisanjeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.brisanjeToolStripMenuItem.Text = "Brisanje";
            this.brisanjeToolStripMenuItem.Click += new System.EventHandler(this.brisanjeToolStripMenuItem_Click);
            // 
            // PocetnaForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 312);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PocetnaForma";
            this.Text = "Dobrodosli";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.PocetnaForma_FormClosed);
            this.Load += new System.EventHandler(this.PocetnaForma_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVreme;
        private System.Windows.Forms.Label lblDatum;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblTelefon;
        private System.Windows.Forms.Label lblPrezime;
        private System.Windows.Forms.Label lblIme;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem alatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unesiAlatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pretragaAlataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proizvodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unosProizvodaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nalogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unosNalogaZaNabavkuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brisanjeNalogaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proizvodniProcesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem izmenaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brisanjeToolStripMenuItem;

    }
}