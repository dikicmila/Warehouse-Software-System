﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;

namespace KorisnickiInterfejs
{
    public partial class UnosAlata : Form
    {
        public UnosAlata()
        {
            InitializeComponent();
        }

        private void UnosAlata_Load(object sender, EventArgs e)
        {
            KontrolerKI.popuniCmbTipMasine(comboBox1);
            KontrolerKI.UnosAlata();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (KontrolerKI.ValidacijaAlat(txtNaziv, txtProizvodjac, txtVrstaAlata, txtCena, comboBox1))
            {
                KontrolerKI.SacuvajAlat(txtNaziv, txtProizvodjac, txtVrstaAlata, txtCena, comboBox1);
                this.Close();
            }     
        }
    }
}
