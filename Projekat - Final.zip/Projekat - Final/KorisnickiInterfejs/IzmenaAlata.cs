﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;
using Biblioteka;

namespace KorisnickiInterfejs
{
    public partial class IzmenaAlata : Form
    {
        Alat alat;

        public IzmenaAlata()
        {
            InitializeComponent();
        }

        public IzmenaAlata(Alat alat)
        {
            InitializeComponent();
            // TODO: Complete member initialization
            this.alat = alat;
            KontrolerKI.popuniCmbTipMasine(comboBox1);
            KontrolerKI.PrikaziAlat(alat, txtNaziv, txtProizvodjac, txtVrsta, comboBox1, txtCena, checkBox1, txtStanje);
        }

        private void IzmenaAlata_Load(object sender, EventArgs e)
        {
            
        }

        private void btnIzmena_Click(object sender, EventArgs e)
        {

            if(KontrolerKI.ValidacijaAlat(txtNaziv,txtProizvodjac,txtVrsta,txtCena,comboBox1) && KontrolerKI.ValidacijaStanje(txtStanje))
                KontrolerKI.IzmeniAlat(alat, txtNaziv, txtProizvodjac, txtVrsta, comboBox1, txtCena, checkBox1, txtStanje);
        }

        private void txtNaziv_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
