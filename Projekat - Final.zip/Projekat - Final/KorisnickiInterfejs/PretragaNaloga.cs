﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;

namespace KorisnickiInterfejs
{
    public partial class PretragaNaloga : Form
    {
        public PretragaNaloga()
        {
            InitializeComponent();
        }

        private void PretragaNaloga_Load(object sender, EventArgs e)
        {
            KontrolerKI.popuniComboZaposlenih(cmbZaposleni);
            KontrolerKI.popuniGridPocetno(cmbZaposleni, dataGridView1);
        }

        private void cmbZaposleni_SelectedIndexChanged(object sender, EventArgs e)
        {
            KontrolerKI.popuniGrid(cmbZaposleni, dataGridView1);
        }

        private void btnBrisi_Click(object sender, EventArgs e)
        {
            if (KontrolerKI.ObrisiNalog(dataGridView1)) this.Close();
        }


    }
}
