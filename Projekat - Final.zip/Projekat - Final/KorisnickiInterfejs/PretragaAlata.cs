﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;
using Biblioteka;
namespace KorisnickiInterfejs
{
    public partial class PretragaAlata : Form
    {
        public PretragaAlata()
        {
            InitializeComponent();
        }

        private void PretragaAlata_Load(object sender, EventArgs e)
        {
            KontrolerKI.popuniCmbTipMasine(comboBox1);
            KontrolerKI.PretragaAlata(dataGridView1);
        }

        private void btnPretrazi_Click(object sender, EventArgs e)
        {
            KontrolerKI.PretragaAlata(txtNaziv, txtVrsta, txtProizvodjac, comboBox1, dataGridView1);
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            Alat alat = dataGridView1.CurrentRow.DataBoundItem as Alat;
            KontrolerKI.PrikaziAlat(alat,txtPrikazNaziv,txtPrikazPro,txtPrikazVrsta,cmbTip,txtPrikazCena,checkBox1,txtPrikazStanje);
        }

        private void btnIzmena_Click(object sender, EventArgs e)
        {
            if (KontrolerKI.DozvoliIzmenuAlata(dataGridView1) != null)
            {
                this.Hide();
                new IzmenaAlata(KontrolerKI.DozvoliIzmenuAlata(dataGridView1)).ShowDialog();
                this.Show();
            }
        }

    }
}
