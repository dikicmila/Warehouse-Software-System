﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;

namespace KorisnickiInterfejs
{
    public partial class PocetnaForma : Form
    {
        public PocetnaForma()
        {
            InitializeComponent();
        }

        private void PocetnaForma_Load(object sender, EventArgs e)
        {
            KontrolerKI.PrikaziUlogovanogRadnika(lblIme, lblPrezime, lblTelefon, lblUser, lblDatum, lblVreme);
        }

        private void PocetnaForma_FormClosed(object sender, FormClosedEventArgs e)
        {
            KontrolerKI.Kraj();
        }

        private void unesiAlatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new UnosAlata().ShowDialog();
            this.Show();
        }

        private void pretragaAlataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new PretragaAlata().ShowDialog();
            this.Show();
        }

        private void unosProizvodaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new UnosProizvoda().ShowDialog();
            this.Show();
        }

        private void unosNalogaZaNabavkuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new UnosNaloga().ShowDialog();
            this.Show();
        }

        private void brisanjeNalogaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new PretragaNaloga().ShowDialog();
            this.Show();
        }

        private void unosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new UnosProizvodnogProcesa().ShowDialog();
            this.Show();
        }

        private void izmenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new IzmenaProizvodnogProcesa().ShowDialog();
            this.Show();
        }

        private void brisanjeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new BrisanjeProizvodnogProcesa().ShowDialog();
            this.Show();
        }

        private void alatToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

    }
}
