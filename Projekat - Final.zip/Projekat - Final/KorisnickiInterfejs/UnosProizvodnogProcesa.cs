﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;
namespace KorisnickiInterfejs
{
    public partial class UnosProizvodnogProcesa : Form
    {
        public UnosProizvodnogProcesa()
        {
            InitializeComponent();
        }

        private void UnosProizvodnogProcesa_Load(object sender, EventArgs e)
        {
            KontrolerKI.popuniComboAlata(cmbAlat);
            KontrolerKI.popuniCmbProizvoda(cmbProizvod);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (KontrolerKI.ValidacijaProizvodniProces(cmbAlat, cmbProizvod, txtBrOperacije, txtOpis))
            {
                if (KontrolerKI.UnosProizvodnogProcesa(cmbAlat, cmbProizvod))
                {
                    KontrolerKI.SacuvajProizvodniProces(txtBrOperacije, txtOpis);
                }
                this.Close();
            }
        }
    }
}
