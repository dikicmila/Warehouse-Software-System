﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KontrolerKorisnickogInterfejsa;
using Biblioteka;
namespace KorisnickiInterfejs
{
    public partial class IzmenaProizvodnogProcesa : Form
    {
        public IzmenaProizvodnogProcesa()
        {
            InitializeComponent();
        }

        private void IzmenaProizvodnogProcesa_Load(object sender, EventArgs e)
        {
            KontrolerKI.vratiProizvodneProcese(dataGridView1);
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            
        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {
            KontrolerKI.IzmeniProizvodniProces(txtBrOp,txtOpis,dataGridView1);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            TehnoloskiProces tp = dataGridView1.CurrentRow.DataBoundItem as TehnoloskiProces;
            KontrolerKI.PrikaziAlat(tp.Alat, txtPrikazNaziv, txtPrikazPro, txtPrikazVrsta, cmbTip, txtPrikazCena, checkBox1, txtPrikazStanje);
            KontrolerKI.PrikaziProizvod(tp.Proizvod, txtNazivPro, txtKupac);
            KontrolerKI.PrikaziProizvodniProces(tp, txtBrOp, txtOpis);
        }

    }
}
